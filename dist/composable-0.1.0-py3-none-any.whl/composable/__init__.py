__version__ = '0.1.0'
from composable.pipeable import (

    pipeable, 
    )
